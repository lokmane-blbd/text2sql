
OPENAI_API_KEY = "key"


